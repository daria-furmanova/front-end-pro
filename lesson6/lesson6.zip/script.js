const items = [
    {
        title: "IPhone 12",
        quantity: 2,
        price: 1000,
    },
    {
        title: "Magic Mouse",
        quantity: 3,
        price: 100,
    },
    {
        title: "MI Band 6",
        quantity: 4,
        price: 50,
    },
    {
        title: "Monitor ASUS",
        quantity: 1,
        price: 700,
    },
    {
        title: "USB Flash Drive",
        quantity: 5,
        price: 20,
    },
];

function totalAmout(products) {
    let sum = 0;
    for (let counter = 0; counter < products.length; counter++) {
        sum = sum + products[counter].quantity * products[counter].price;
    }
     alert(` Общая стоимость вашего заказа: ` + sum + ` $ `);
}

totalAmout(items);

 function avaragePriceOfOneProduct(products) {
     let totalQuantity = 0;
     let sum = 0;
     for (let counter = 0; counter < products.length; counter++) {
         totalQuantity = totalQuantity + products[counter].quantity;
     }
     for (let counter = 0; counter < products.length; counter++) {
        sum = sum + products[counter].quantity * products[counter].price;
    }
    return result = sum / totalQuantity;
 } 

 alert (` Средняя цена 1 товара: ` + avaragePriceOfOneProduct(items) + ` $ ` );

items.sort(function(a, b){
    return a.price - b.price
}); 

console.log (items.sort())
